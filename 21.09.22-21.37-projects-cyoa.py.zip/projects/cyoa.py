"""Choose your own adventure: Horror Movie Edition."""

__author__ = "730515642"

from random import randint

START_EMOJI: str = "\U0001F603"

player: str
points: int
friend_one: str
friend_two: str
path: str


def greet() -> None:
    """Greeting the player and introducing the game."""
    global player
    global friend_one
    global friend_two
    print(f"Welcome to \"Would You Survive a Horror Movie?\"\nWalk through THIS to find out! WARNING: Chances of surviving are low.{START_EMOJI}")
    player = input("To begin, what is your name? ")
    friend_one = input("Pick a friend to join you on your journey: ")
    friend_two = input("Pick another friend to join you on your journey: ")


def main() -> None:
    """Main three choices: Cabin, Woods, and Exit."""
    global points
    global player
    global friend_one
    global friend_two
    global path
    greet()
    points = 0 
    playing: str = ""
    while playing == "Yes" or "yes":
        choice_one: str = input(f"\nWelcome~ You and your friend have arrived in front of a lonely cabin in the middle of the snowy woods. The wind is howling, and the trees seem to be growing in size and darkness behind you~\nYour friend {friend_one}, calls to you: \"{player}! Where's {friend_two}?\nWith a start you realize {friend_two} has gone missing! Now what would you like to do?\n1. Enter the cabin. Maybe your friend went inside.\n2. Turn back and enter the woods. Maybe your friend ran back to look for you and {friend_one}.\n3. Find your way back home. Your friend {friend_two} is probably the more sensible of the three of you, and went back home too: [END of Experience]\n Enter a choice number: ")
        if int(choice_one) == 1:
            cabin()
        if int(choice_one) == 2:
            print(f"\n\"{player}! Which way do you think {friend_two} went?\" Oh no, you realize. There are multiple paths through the woods, and you don't know which one {friend_two} went through, or which one you came from. So which path do you choose?")
            # Trust die or choose your own path?
            choice_two: int = int(input("\nLuckily you have your trusty 4 sided die on you to make the hard choices for you.\nDo you want to 1. roll the die, letting fate decide your path, or 2. choose the path yourself?\nEnter 1 or 2: "))
            points = woods(points, choice_two)
            path_leads(int(path))
        if int(choice_one) == 3: 
            points = points + 1000
            print(f"\n[END of experience]: You've gained a total of {points} points! You would definitely survive a horror movie. But, who knows if your friend {friend_two} actually went home...\nIf not, maybe we'll see you in front of the cabin once again... but goodbye for now...")
        playing = input(f"You've accumulated a total of {points} survival points.\nWould you like to continue playing?\nEnter yes or no: ")


def cabin() -> None:
    """Going in the Cabin, and choosing between 2 doors."""
    global player
    global points
    global friend_one
    global friend_two
    print(f"\nYou open the door to the cabin, and {friend_one} follows you. It's dark and eery inside, but at least it's not as cold as outside. You call out {friend_two}'s name, and you hear a unsettling voice respond back. You turn to the two doors on the opposite side of the entrance. Both are closed.")
    choice_one: str = input(f"\"{player}, maybe {friend_two} is inside one of those doors? Let's go inside.\" {friend_one} says. Ok, you say. Which door do you want to enter?\nEnter 1 or 2: ")
    # You enter door 1
    if int(choice_one) == 1:
        points = points - 1
        choice_two: str = input(f"\nSomething flies straight into your face as you open the door. You scream, and {friend_one} follows(with the screaming). Two hands clamp over your mouths, and drag you to the depths of the room.\nYou do the following:\n1. Struggle\n2. Accept your fate\nEnter 1 or 2: ")
        # You struggle
        if int(choice_two) == 1:
            print(f"\nYou fight against the hand and they release you abruptly. \"It's me guys!\" You hear a harsh whisper and turn around to see {friend_two}. You're about to speak when {friend_two} shuts both of your mouths again. \"Don't talk loudly. I heard someone upstairs. Let's leave through the window.\"")
            choice_three: str = input(f"{friend_one} speaks up: \"Wait, I left my keys in the main hall! Could we go get them?\"\n Do you say:\n1. Ok\n2. No, are you crazy? Who cares about your keys?\nEnter 1 or 2: ")
            # You go back for the keys
            if int(choice_three) == 1:
                points = points - 1
                print(f"\nYou go out into the hall, as carefully as possible, to grab {friend_one}'s keys and go. But you hear an unfamiliar footstep and turn to see a swipe of black and a deathly white mask, before you fall to the ground, unmoving.")
                print(f"\nSadly this is the end. Your chances of survival points accumulated to {points} points. Maybe if you hadn't gone back for the keys you would have survived. Or if you hadn't entered the cabin at all.")
                return None
            # You don't go back for the keys
            if int(choice_three) == 2:
                points = points + 1
                print(f"\n{friend_one} and {friend_two} nod in understanding. \"You can always replace your car, but you can't replace a life.\" {friend_two} says sagely. You agree, and the three of you quietly open the window and climb through, escaping.")
                print(f"\nYou made it out! Your chances of survival points accumulated to {points} points, as you managed to escape safely, even though you probably shouldn't have entered the cabin in the first place.")
                return None
        # You accept your fate
        if int(choice_two) == 2:
            points = points - 1
            print(f"\nYou accept your fate. The last thing you see is {friend_one}'s eyes before you fall unconsious.")
            print(f"Sadly this is the end. Your chances of survival points accumulated to {points} points. Maybe if you fought back you would have survived...")
            return None
    # You enter door 2
    if int(choice_one) == 2: 
        points = points - 1
        choice_four: str = input(f"\nOpening the door, you're now in a bedroom of some kind. You look around for {friend_two}, but no response. Disappointed, you sigh, but {friend_one} lets out a gasp as the door clicks behind you. You turn around, alarmed. You only see a flash of black and white before something resembling a pan descends on your head, knocking you out.\n\nYou wake up a little later to a sound, and someone pushing you awake. With shock you see that it's {friend_two}.\"{friend_two}! You're here!\" You exclaim. {friend_two} nods, but something seems off with how they appear. \"Wait, where's {friend_one}?\" You ask. They shake their head and tell you to come with them and suspicion and alarm grows inside you. What do you do?\n1. Follow them or, 2. Run away while you have the chance\nEnter 1 or 2: ")
        if int(choice_four) == 1:
            points = points - 1
            print(f"\nYou nod your head slowly and follow {friend_two}. {friend_two} leads you into another room, and as you enter, the door locks shut behind you. You pound on the door, screaming for {friend_two} to let you out, but you get no response. You grow dizzy and fall onto the ground, your consiousness leaving you as you realize {friend_two} was nothing more than a hallucination.")
            print(f"\nSadly this is the end. Your chances of survival points accumulated to {points} points. Maybe if you made smarter decisions you would have survived... ")
        if int(choice_four) == 2:
            points = points - 1
            print(f"\nYou're wariness kicks in, like it should have a million decisions ago, and you get up slowly, before you sprint away. {friend_two} chases after you, but the footsteps recede as you dash through the woods, ignoring everything around you. Only when you reach the street where you came from do you realize that {friend_one} is nowhere to be seen.")
            print(f"\nYou've successfully made it out. Your chances of survival points accumulated to {points} points, as you managed to escape safely, but who knows what happened to {friend_one}...")


# Randomize your fate or choose your own?
def woods(x: int, y: int) -> int:
    """Going into the woods and choosing if you want to randomly choose your path or choose it yourself."""
    global path
    global friend_one
    global friend_two
    global player
    if y == 1:
        x = x - 1
        path = str(randint(1, 4))
        print(f"\nYou, {player}, decide you can't make decisions yourself after all, and roll the die. It lands on the snow, with a {path} showing.\nAlright, path {path} it is you decide. You enter path {path} with {friend_one} in tow.")
    if y == 2:
        x = x + 1
        path = input("\nWhat path would you like to choose? Path 1, 2, 3, or 4?\nEnter 1, 2, 3, or 4: ")
    return x


def path_leads(x: int) -> None:
    """Going into the path in the woods you have chosen for yourself."""
    global points
    global friend_one
    global player
    global friend_two
    # footsteps and bridge
    if x == 1:
        points = points - 1
        choice_one: str = input(f"\nAs you're about to enter what you think is the first and right path, you hear sudden thuds echoing behind you. Footsteps rush torwards your direction, and so you grab {friend_one} running. You don't look back.\n\nYou both arrive in a fork in the road, with footsteps still closely behind you.\n\nDo you want to go 1. left, or 2. right?\n\nEnter 1 or 2: ")
        if int(choice_one) == 1:
            points = points - 1
            choice_two: str = input("\nYou reach a bridge constructed over a ridge that seems way too big to be in the middle of the woods, but the woods are haunted, so you can't complain. The ridge is probably smaller than it looks right?\nThe footsteps seem to close on behind you, and you have to make a decision, now, FAST!\nDo you 1. jump over the ridge with what litlle leg strength you have or 2. trust the bridge's planks?\nEnter 1 or 2:")
            if int(choice_two) == 1:
                points = points - 1
                print(f"\n\"JUMP!\" You say, and {friend_one} follows, albeit begrudingly.\n\nBut all of a sudden, your knee weakens, and you lose your footing. Your hands flail, {friend_one} screams as she's dragged down by you, and you grab onto one of the ropes dangling from the bridge. It doesn't help: It snaps from the weight of you both, and you and {friend_one} both fall to your demise.")
                print(f"\nSadly this is the end. Your chances of survival points accumulated to {points} points. Maybe if you made smarter decisions you would have survived... ")
            if int(choice_two) == 2:
                points = points + 1
                print(f"\nYou hold onto {friend_one}'s hand, and you both make your way across the bridge slowly. But just as you cross, the bridge snaps!\n\nYou jump the last bit safely, heart pounding. Either way you've miraculously survived, and scurry off back home.")
                print(f"\nYou made it out! Your chances of survival points accumulated to {points} points, as you managed to escape safely, even though you probably shouldn't have been so reckless with the woods.")
        if int(choice_one) == 2:
            points = points - 1
            print("The right was the wrong decision to pick because the path is littered with thornes. You're too far in though, and continue through, but the footsteps behind you grow closer and closer until your frantic running away from them doesn't help anymore. A tall figure descends over you both, with a bat in hand.")
            print(f"\nSadly this is the end. Your chances of survival points accumulated to {points} points. Maybe if you made smarter decisions you would have survived... ")
    # wolf
    if x == 2:
        points = points - 1
        print(f"\n\"Are you sure this is the right path?\" {friend_one} asks doubtfully. You nod, but honestly, {friend_one} has a point. The second path seems darker than the rest, but you've made up your mind.")
        choice_five: str = input(f"\nAs you both walk through the path, you hear a wolf calling into the night. It seems suspiciously close, but it also could be {friend_two}, who can do a surprisingly extremely accurate wolf mating call.\nShould you 1. Go after the sound or 2. Run away?\nEnter 1 or 2: ")
        if int(choice_five) == 1:
            points = points - 1
            print(f"\nYou and {friend_one} go after the sound, determined that it's {friend_two}. \"It sounds just like {friend_two}!\" {friend_one} says. You agree and follow.\n\nBut then an actual wolf jumps out! You run, but the wolf catches up, and well, you know what happens next...")
            print(f"\nSadly this is the end. Your chances of survival points accumulated to {points} points. Maybe if you made smarter decisions you would have survived... ")
        if int(choice_five) == 2:
            points = points + 1
            print(f"You run away, which is probably the smarter thing to do, and thankfully it is, because the sound of the wolf fades away as you suddenly realize it wasn't {friend_two} after all...")
            print(f"\nYou made it out! Your chances of survival points accumulated to {points} points, as you managed to escape safely, even though you probably shouldn't have been so reckless with the woods.")
    # lucked out, but points is still reduced because being lucky is sheer chance
    if x == 3:
        points = points - 1
        print(f"\nSurprisingly, the third path has a clear way out. Too clear in fact, since the path leads directly back to the street you arrived from, with no chasms of death or blood drinking vampires on the way. Realizing the gacha rng gods have blessed you, you and {friend_one} escape safely with no trouble.")
        print(f"\nYou made it out! Your chances of survival points accumulated to {points} points, as you managed to escape safely, even though you probably shouldn't have been so reckless with the woods.")
    # not as lucky
    if x == 4:
        points = points - 1
        print(f"\nNot surprisingly, as you enter the fourth and last path through the woods, you realize it was probably a bad idea. The woods creak and groan as you move through, and {friend_one} mutters about how they never should have followed you into the woods in the first place. You reach a dead end in the woods, and when you turn back from it, you realize you have no idea where you are. You're stuck, and there's no way to get out.")
        print(f"\nSadly this is the end. Your chances of survival points accumulated to {points} points. Maybe if you made smarter decisions you would have survived... ")


# runs program
if __name__ == "__main__":
    main()